 <div class="container-fluid">

 	<div class="col-md-12 col-lg-12 text-right" style="margin-top:5px;">
 		 <a href="<?php echo base_url();?>events" class="btn btn-info btn-sm">Back to events</a>
 	</div>
 	<div class="col-md-12 col-lg-12">
	 	<div class="col-md-8 col-lg-8">
	     	<h4 class="page-section-heading">Online training : Audit Staff Training Workshop: Coast Branch</h4>
	     	  <div class="embed-responsive embed-responsive-4by3">
	                <iframe class="embed-responsive-item" src="//player.vimeo.com/video/50522981?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff&amp;height=50px"></iframe>
	            </div>
		       
	    </div>
	    <div class="col-md-4 col-lg-4">
	    	 <form class="form" role="form">
	    	 	<div class="form-group margin-none">
	    	 			
		                <div class="col-sm-12" style=" margin-top:10%;">
		                   		
		                    <div class="col-sm-12">
		                   		 Antendants
		                    	<div class="progress">
		                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
		                                <span class="sr-only">40% Complete (success)</span>
		                            </div>
		                        </div>
		                        <div class="progress">
		                            <div class="progress-bar progress-bar-default" role="progressbar" aria-valuenow="7" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
		                                <span class="sr-only">40% Complete (success)</span>
		                            </div>
		                        </div>
		                      </div>
	                  </div>
	                </div>
	    	 </form>
	    </div>
	</div>
</div>