
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Upcoming Meetings (4) <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
       <!--  <li class="active"><a href="<?php echo base_url();?>home">Timeline</a>
        </li> -->
       
        <!-- <li><a href="<?php echo base_url();?>friends">Friends</a>
        </li> -->
        <li class="dropdown-header">Private User Pages <p>gjdshajs</p></li>
        <li><a href="<?php echo base_url();?>messages">Messages kjgfkjsgdfs ksjgdkjada jgdjagshd</a>
        </li>
        <li><a href="<?php echo base_url();?>profile">Profile</a>
        </li>
        
    </ul>