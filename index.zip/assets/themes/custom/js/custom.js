
$(document).ready(function() {
});

$("input.alert-danger").change(function() {
	$(this).removeClass('alert-danger');
});

$("select.alert-danger").change(function() {
	$(this).removeClass('alert-danger');
});

$("textarea.alert-danger").keyup(function() {
	$(this).removeClass('alert-danger');
});

